# Jarvis Assistant - Руководство по установке и настройке

## Описание проекта

**Jarvis Assistant** — это полнофункциональное приложение для Android на React Native, которое работает как голосовой ассистент с поддержкой русского языка. Приложение распознает голосовые команды, выполняет действия (открытие приложений, поиск в YouTube/Google) и отвечает голосом.

## Системные требования

- **Node.js**: версия 16.0.0 или выше
- **npm** или **yarn**: для управления зависимостями
- **Android SDK**: API 24 (Android 7.0) или выше
- **Java Development Kit (JDK)**: версия 11 или выше
- **React Native CLI**: установить через `npm install -g react-native-cli`

## Структура проекта

```
jarvis-assistant/
├── App.js                          # Основной компонент приложения
├── index.js                        # Точка входа приложения
├── app.json                        # Метаданные приложения
├── package.json                    # Зависимости проекта
├── babel.config.js                 # Конфигурация Babel
├── metro.config.js                 # Конфигурация Metro bundler
├── android/
│   └── app/
│       ├── build.gradle            # Конфигурация сборки Android
│       └── src/main/
│           └── AndroidManifest.xml # Манифест приложения с разрешениями
└── SETUP_GUIDE.md                  # Этот файл
```

## Шаг 1: Установка зависимостей

Перейдите в директорию проекта и установите все необходимые пакеты:

```bash
cd jarvis-assistant
npm install
# или
yarn install
```

## Шаг 2: Настройка Android окружения

### 2.1 Установка Android SDK

Убедитесь, что у вас установлены следующие компоненты Android SDK:
- Android SDK Platform 34 (или выше)
- Android SDK Build-Tools 34.0.0
- Android Emulator (опционально)

### 2.2 Установка переменных окружения

Добавьте переменные окружения в ваш профиль shell (`.bashrc`, `.zshrc` или аналогичный):

```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/tools
export PATH=$PATH:$ANDROID_HOME/tools/bin
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

После добавления переменных выполните:

```bash
source ~/.bashrc  # или ~/.zshrc
```

## Шаг 3: Настройка разрешений Android

Файл `android/app/src/main/AndroidManifest.xml` уже содержит все необходимые разрешения:

- **RECORD_AUDIO**: Для доступа к микрофону
- **INTERNET**: Для поиска в Google и YouTube
- **FOREGROUND_SERVICE**: Для работы в фоновом режиме
- **FOREGROUND_SERVICE_MICROPHONE**: Для использования микрофона в фоновом сервисе

## Шаг 4: Установка зависимостей React Native

Свяжите нативные модули (обычно выполняется автоматически):

```bash
npx react-native link
```

Если возникают проблемы с `@react-native-voice/voice`, выполните:

```bash
npx react-native link @react-native-voice/voice
npx react-native link react-native-tts
npx react-native link @supersami/react-native-foreground-service
```

## Шаг 5: Запуск приложения

### 5.1 На физическом устройстве

1. Подключите Android-устройство через USB
2. Убедитесь, что отладка USB включена на устройстве
3. Выполните команду:

```bash
npx react-native run-android
```

### 5.2 На эмуляторе

1. Запустите Android Emulator:

```bash
$ANDROID_HOME/emulator/emulator -avd <имя_виртуального_устройства>
```

2. Выполните команду:

```bash
npx react-native run-android
```

## Шаг 6: Тестирование приложения

### Тест 1: Активация системы

1. Откройте приложение на устройстве
2. Нажмите кнопку **"▶ Активировать"**
3. Вы должны услышать голосовой ответ: **"Система активна"**

### Тест 2: Поиск на YouTube

1. Убедитесь, что система активирована
2. Сверните приложение (нажмите кнопку Home)
3. Скажите громко: **"Джарвис найди в ютубе футбол"**
4. Приложение YouTube должно открыться с результатами поиска

### Тест 3: Открытие приложения

1. Скажите: **"Джарвис открой Telegram"**
2. Приложение Telegram должно открыться

### Тест 4: Поиск в Google

1. Скажите: **"Джарвис найди погода в Москве"**
2. Браузер должен открыться с результатами поиска

## Доступные команды

| Команда | Описание |
|---------|---------|
| "Джарвис открой YouTube" | Открывает приложение YouTube |
| "Джарвис открой Telegram" | Открывает приложение Telegram |
| "Джарвис открой камеру" | Открывает приложение камеры |
| "Джарвис найди в ютубе [запрос]" | Ищет видео на YouTube |
| "Джарвис найди [запрос]" | Ищет в Google |
| "Джарвис привет" | Приветствие |
| "Джарвис спасибо" | Благодарность |

## Решение проблем

### Проблема: Микрофон не работает

**Решение:**
1. Проверьте, что приложению выданы разрешения на доступ к микрофону:
   - Перейдите в Параметры → Приложения → Jarvis Assistant → Разрешения
   - Убедитесь, что разрешение "Микрофон" включено

2. Перезагрузите приложение

### Проблема: Фоновый режим не работает

**Решение:**
1. Убедитесь, что в `AndroidManifest.xml` добавлены разрешения `FOREGROUND_SERVICE` и `FOREGROUND_SERVICE_MICROPHONE`
2. Проверьте, что приложение не отключено в параметрах батареи

### Проблема: Ошибка "Cannot find module '@react-native-voice/voice'"

**Решение:**
```bash
npm install @react-native-voice/voice --save
npx react-native link @react-native-voice/voice
```

### Проблема: Приложение не запускается

**Решение:**
1. Очистите кэш:
```bash
npx react-native start --reset-cache
```

2. В другом терминале:
```bash
npx react-native run-android
```

## Дополнительная настройка

### Изменение языка распознавания речи

Откройте `App.js` и найдите строку:

```javascript
const LANGUAGE_CODE = 'ru-RU';
```

Измените на нужный язык:
- `en-US` — английский (США)
- `fr-FR` — французский
- `de-DE` — немецкий
- `es-ES` — испанский

### Изменение ключевого слова

Найдите в `App.js`:

```javascript
const JARVIS_KEYWORD = 'джарвис';
```

Измените на нужное слово.

### Добавление новых команд

В функции `processCommand` добавьте новое условие:

```javascript
else if (cleanCommand.includes('ваша команда')) {
  await speak('Ответ ассистента');
  // Ваш код здесь
}
```

## Публикация в Google Play Store

1. Создайте подписанный APK:
```bash
cd android
./gradlew assembleRelease
```

2. Подпишите APK с помощью jarsigner
3. Загрузите на Google Play Console

## Поддержка и документация

- **React Native**: https://reactnative.dev/
- **@react-native-voice/voice**: https://github.com/react-native-voice/voice
- **react-native-tts**: https://github.com/ak1394/react-native-tts
- **@supersami/react-native-foreground-service**: https://github.com/supersami/react-native-foreground-service

## Лицензия

MIT

## Автор

Jarvis Assistant Development Team
