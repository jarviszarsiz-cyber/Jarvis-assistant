import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  PermissionsAndroid,
  Linking,
  Platform,
  Alert,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import Voice from '@react-native-voice/voice';
import Tts from 'react-native-tts';
import RNForegroundService from '@supersami/react-native-foreground-service';

const App = () => {
  const [isJarvisActive, setIsJarvisActive] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [recognizedText, setRecognizedText] = useState('');
  const [partialResults, setPartialResults] = useState([]);
  const [error, setError] = useState('');
  const [commandHistory, setCommandHistory] = useState([]);

  const JARVIS_KEYWORD = 'джарвис';
  const LANGUAGE_CODE = 'ru-RU';

  useEffect(() => {
    // Initialize TTS
    Tts.setDefaultLanguage(LANGUAGE_CODE);
    Tts.setDefaultRate(0.5);
    Tts.setDefaultPitch(1.0);

    // Initialize Voice listeners
    Voice.onSpeechStart = _onSpeechStart;
    Voice.onSpeechEnd = _onSpeechEnd;
    Voice.onSpeechResults = _onSpeechResults;
    Voice.onSpeechPartialResults = _onSpeechPartialResults;
    Voice.onSpeechError = _onSpeechError;

    // Request permissions on component mount
    requestPermissions();

    return () => {
      // Clean up Voice listeners
      Voice.destroy().then(Voice.removeAllListeners);
      // Stop foreground service if running
      if (Platform.OS === 'android') {
        RNForegroundService.stop();
      }
    };
  }, []);

  const requestPermissions = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.requestMultiple([
          PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
          PermissionsAndroid.PERMISSIONS.FOREGROUND_SERVICE,
        ]);
        if (
          granted['android.permission.RECORD_AUDIO'] === PermissionsAndroid.RESULTS.GRANTED &&
          granted['android.permission.FOREGROUND_SERVICE'] === PermissionsAndroid.RESULTS.GRANTED
        ) {
          console.log('Permissions granted');
        } else {
          console.log('Permissions denied');
          Alert.alert('Разрешения', 'Требуются разрешения на доступ к микрофону и фоновому сервису.');
        }
      } catch (err) {
        console.warn(err);
      }
    }
  };

  const _onSpeechStart = (e) => {
    console.log('onSpeechStart: ', e);
    setIsListening(true);
    setError('');
  };

  const _onSpeechEnd = (e) => {
    console.log('onSpeechEnd: ', e);
    setIsListening(false);
    // Automatically restart listening if Jarvis is active
    if (isJarvisActive) {
      setTimeout(() => _startRecognizing(), 500);
    }
  };

  const _onSpeechResults = async (e) => {
    console.log('onSpeechResults: ', e);
    if (e.value && e.value.length > 0) {
      const text = e.value[0].toLowerCase();
      setRecognizedText(text);
      
      if (isJarvisActive && text.includes(JARVIS_KEYWORD)) {
        addToHistory(`Распознано: ${text}`);
        await processCommand(text);
      } else if (isJarvisActive) {
        // If Jarvis is active but keyword not found, restart listening
        setTimeout(() => _startRecognizing(), 500);
      }
    }
  };

  const _onSpeechPartialResults = (e) => {
    console.log('onSpeechPartialResults: ', e);
    if (e.value && e.value.length > 0) {
      setPartialResults(e.value);
    }
  };

  const _onSpeechError = (e) => {
    console.log('onSpeechError: ', e);
    setError(JSON.stringify(e.error));
    setIsListening(false);
    // Automatically restart listening if Jarvis is active and an error occurs
    if (isJarvisActive) {
      setTimeout(() => _startRecognizing(), 1000);
    }
  };

  const _startRecognizing = async () => {
    setRecognizedText('');
    setPartialResults([]);
    setError('');
    try {
      await Voice.start(LANGUAGE_CODE);
      console.log('Voice recognition started');
    } catch (e) {
      console.error(e);
    }
  };

  const _stopRecognizing = async () => {
    try {
      await Voice.stop();
      console.log('Voice recognition stopped');
    } catch (e) {
      console.error(e);
    }
  };

  const speak = async (text) => {
    await Tts.stop(); // Stop any ongoing speech
    await Tts.speak(text);
  };

  const addToHistory = (message) => {
    setCommandHistory(prev => [message, ...prev].slice(0, 10));
  };

  const processCommand = async (command) => {
    // Remove JARVIS_KEYWORD for easier command parsing
    const cleanCommand = command.replace(JARVIS_KEYWORD, '').trim();

    if (cleanCommand.includes('найди в ютубе')) {
      const query = cleanCommand.split('найди в ютубе')[1]?.trim();
      if (query) {
        await speak(`Ищу на YouTube ${query}, сэр.`);
        addToHistory(`Команда: Поиск YouTube - ${query}`);
        const url = `vnd.youtube://results?search_query=${encodeURIComponent(query)}`;
        Linking.canOpenURL(url).then(supported => {
          if (supported) {
            Linking.openURL(url);
          } else {
            Linking.openURL(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
          }
        });
      } else {
        await speak('Что именно искать на YouTube, сэр?');
      }
    } else if (cleanCommand.includes('найди в гугле') || cleanCommand.includes('найди')) {
      const query = cleanCommand.split('найди')[1]?.trim();
      if (query) {
        await speak(`Ищу в Google ${query}, сэр.`);
        addToHistory(`Команда: Поиск Google - ${query}`);
        const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        Linking.canOpenURL(url).then(supported => {
          if (supported) {
            Linking.openURL(url);
          } else {
            Alert.alert('Ошибка', 'Не удалось открыть Google.');
          }
        });
      } else {
        await speak('Что именно искать, сэр?');
      }
    } else if (cleanCommand.includes('открой youtube') || cleanCommand.includes('открой ютуб')) {
      await speak('Открываю YouTube, сэр.');
      addToHistory('Команда: Открыть YouTube');
      Linking.canOpenURL('vnd.youtube://').then(supported => {
        if (supported) {
          Linking.openURL('vnd.youtube://');
        } else {
          Linking.openURL('https://www.youtube.com');
        }
      });
    } else if (cleanCommand.includes('открой telegram') || cleanCommand.includes('открой телеграм')) {
      await speak('Открываю Telegram, сэр.');
      addToHistory('Команда: Открыть Telegram');
      Linking.canOpenURL('tg://').then(supported => {
        if (supported) {
          Linking.openURL('tg://');
        } else {
          Alert.alert('Ошибка', 'Не удалось открыть Telegram. Убедитесь, что приложение установлено.');
        }
      });
    } else if (cleanCommand.includes('открой камеру')) {
      await speak('Открываю камеру, сэр.');
      addToHistory('Команда: Открыть камеру');
      Alert.alert('Камера', 'Пожалуйста, откройте приложение камеры вручную, если оно не запустилось автоматически.');
    } else if (cleanCommand.includes('привет') || cleanCommand.includes('привет джарвис')) {
      await speak('Здравствуйте, сэр. Я готов помочь.');
      addToHistory('Команда: Приветствие');
    } else if (cleanCommand.includes('спасибо')) {
      await speak('Всегда пожалуйста, сэр.');
      addToHistory('Команда: Спасибо');
    } else {
      await speak('Я не понял команду, повторите, сэр.');
      addToHistory('Ошибка: Команда не распознана');
    }
    // Ensure listening restarts after command processing
    setTimeout(() => _startRecognizing(), 1000);
  };

  const toggleJarvis = async () => {
    if (isJarvisActive) {
      // Deactivate Jarvis
      await speak('Система деактивирована.');
      addToHistory('Система: Деактивирована');
      _stopRecognizing();
      if (Platform.OS === 'android') {
        RNForegroundService.stop();
      }
      setIsJarvisActive(false);
    } else {
      // Activate Jarvis
      await speak('Система активна.');
      addToHistory('Система: Активирована');
      if (Platform.OS === 'android') {
        // Configure and start foreground service
        RNForegroundService.configure({
          id: 123,
          notificationTitle: 'Jarvis Assistant',
          notificationBody: 'Слушаю команды...', 
          notificationColor: '#007AFF',
        });
        await RNForegroundService.start();
      }
      _startRecognizing();
      setIsJarvisActive(true);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        <Text style={styles.title}>🤖 Jarvis Assistant</Text>
        
        <TouchableOpacity onPress={toggleJarvis} style={[styles.button, isJarvisActive && styles.buttonActive]}>
          <Text style={styles.buttonText}>
            {isJarvisActive ? '⏹ Деактивировать' : '▶ Активировать'}
          </Text>
        </TouchableOpacity>

        <View style={styles.statusContainer}>
          <Text style={styles.statusLabel}>Статус системы:</Text>
          <Text style={[styles.statusValue, isJarvisActive && styles.statusActive]}>
            {isJarvisActive ? '✓ Активна' : '✗ Неактивна'}
          </Text>
        </View>

        <View style={styles.statusContainer}>
          <Text style={styles.statusLabel}>Микрофон:</Text>
          <View style={styles.listeningIndicator}>
            {isListening && <ActivityIndicator size="small" color="#007AFF" />}
            <Text style={[styles.statusValue, isListening && styles.listeningText]}>
              {isListening ? 'Слушаю...' : 'Ожидаю'}
            </Text>
          </View>
        </View>

        {recognizedText ? (
          <View style={styles.resultContainer}>
            <Text style={styles.resultLabel}>Распознано:</Text>
            <Text style={styles.resultText}>{recognizedText}</Text>
          </View>
        ) : null}

        {partialResults.length > 0 ? (
          <View style={styles.partialContainer}>
            <Text style={styles.partialLabel}>Частично:</Text>
            <Text style={styles.partialResultText}>{partialResults[0]}</Text>
          </View>
        ) : null}

        {error ? (
          <View style={styles.errorContainer}>
            <Text style={styles.errorLabel}>Ошибка:</Text>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}

        <View style={styles.historyContainer}>
          <Text style={styles.historyTitle}>История команд:</Text>
          {commandHistory.length > 0 ? (
            commandHistory.map((item, index) => (
              <Text key={index} style={styles.historyItem}>
                • {item}
              </Text>
            ))
          ) : (
            <Text style={styles.historyEmpty}>Нет команд</Text>
          )}
        </View>

        <View style={styles.commandsContainer}>
          <Text style={styles.commandsTitle}>Доступные команды:</Text>
          <Text style={styles.commandItem}>🎤 "Джарвис открой YouTube"</Text>
          <Text style={styles.commandItem}>🎤 "Джарвис найди в ютубе [запрос]"</Text>
          <Text style={styles.commandItem}>🎤 "Джарвис найди [запрос]"</Text>
          <Text style={styles.commandItem}>🎤 "Джарвис открой Telegram"</Text>
          <Text style={styles.commandItem}>🎤 "Джарвис открой камеру"</Text>
          <Text style={styles.commandItem}>🎤 "Джарвис привет"</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5FCFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingVertical: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#333',
  },
  button: {
    backgroundColor: '#007AFF',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 10,
    marginBottom: 30,
    width: '100%',
    alignItems: 'center',
  },
  buttonActive: {
    backgroundColor: '#FF3B30',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  statusContainer: {
    width: '100%',
    backgroundColor: '#E8F4F8',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderLeftWidth: 4,
    borderLeftColor: '#007AFF',
  },
  statusLabel: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
  },
  statusValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 5,
  },
  statusActive: {
    color: '#34C759',
  },
  listeningIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  listeningText: {
    marginLeft: 10,
    color: '#007AFF',
  },
  resultContainer: {
    width: '100%',
    backgroundColor: '#F0F0F0',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
  },
  resultLabel: {
    fontSize: 12,
    color: '#999',
    fontWeight: '600',
  },
  resultText: {
    fontSize: 16,
    color: '#333',
    marginTop: 8,
    fontStyle: 'italic',
  },
  partialContainer: {
    width: '100%',
    backgroundColor: '#F9F9F9',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderLeftWidth: 3,
    borderLeftColor: '#FFA500',
  },
  partialLabel: {
    fontSize: 12,
    color: '#999',
    fontWeight: '600',
  },
  partialResultText: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
  errorContainer: {
    width: '100%',
    backgroundColor: '#FFE8E8',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderLeftWidth: 3,
    borderLeftColor: '#FF3B30',
  },
  errorLabel: {
    fontSize: 12,
    color: '#999',
    fontWeight: '600',
  },
  errorText: {
    fontSize: 14,
    color: '#FF3B30',
    marginTop: 8,
  },
  historyContainer: {
    width: '100%',
    backgroundColor: '#F5F5F5',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  historyItem: {
    fontSize: 13,
    color: '#666',
    marginVertical: 4,
  },
  historyEmpty: {
    fontSize: 13,
    color: '#999',
    fontStyle: 'italic',
  },
  commandsContainer: {
    width: '100%',
    backgroundColor: '#E8F8E8',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
  },
  commandsTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  commandItem: {
    fontSize: 13,
    color: '#333',
    marginVertical: 5,
    paddingLeft: 10,
  },
});

export default App;
